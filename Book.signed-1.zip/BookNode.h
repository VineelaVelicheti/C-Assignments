#ifndef BOOKNODE_H_
#define BOOKNODE_H_

#include "Book.h"

/**
 * A book node in a linked list.
 */
class BookNode
{
public:
	/**
     * Constructor.
     * @param book this node's book.
     */
	BookNode(Book book);

	// Get Book details from Book Node
    Book getbook();

    //set next BookNode value
    void setnext(BookNode *booknode);

    // get next BookNode value
    BookNode * getnext();

    //Destructor for Book Node Class
    ~BookNode();

private:
    Book book;       // this node's book
    BookNode *next;  // link to the next node in the list
};

#endif /* BOOKNODE_H_ */