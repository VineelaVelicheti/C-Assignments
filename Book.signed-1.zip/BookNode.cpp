#include<iostream>
#include "BookNode.h"
#include "Book.h"


using namespace std;

//Parameter Constructor for Book Node Class
BookNode::BookNode(Book bookObject)
{
	book=bookObject;
	next=nullptr;
}

// Function to get Book details
Book BookNode::getbook()
{
	return book;
}

// Function to set next Book Node
void BookNode::setnext(BookNode *booknode)
{
	next=booknode;
}

//Function to get the next Book Node in the List
BookNode * BookNode::getnext()
{
	return next;
}

//Destructor for Book Node Class
BookNode::~BookNode()
{

}