#ifndef BOOKLIST_H_
#define BOOKLIST_H_

#include<iostream>
#include<string>
#include"BookNode.h"
#include "Book.h"

using namespace std;
/**
 * A list of book nodes.
 */
class BookList
{
public:

	// Default Constructor
	BookList();
    /**
     * Constructor.
     * @param name the name of this list.
     */
    BookList(const string name);

    // Function to set the BookList name
    void setname(string booklistname);
    /**
     * Print the list.
     */
    void print();

    // Function to Create a BookList dynamically
    void create();

    //Function to add Books to a BookList
    void add(const Book & bookObject);

    //Function to merge a book list with an existing Book List
    void merge(const BookList & booklist);

    //Function to split the Book List based on author last name
    void splita2m(const BookList & booklist);

    //Function to split the Book List based on author last name
    void splitn2z(const BookList & booklist);

    // Destructor to delete dynamic variables
    ~BookList();

private:
    string name;      // name of this book list
    BookNode *head;   // head of the list of book nodes
    BookNode *tail;   // tail of the list of book nodes
};

#endif /* BOOKLIST_H_ */