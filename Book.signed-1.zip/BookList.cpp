#include<iostream>
#include<fstream>
#include<string>
#include "BookList.h"
#include "BookNode.h"
#include "Book.h"

using namespace std;

//Default Constructor for BookList Class
BookList::BookList() : name(""), head(nullptr), tail(nullptr)
{

}

// Parameter constructor for Book List class
// Parameter is a const string name which is the name of Book List
BookList::BookList(const string name)
    : name(name), head(nullptr), tail(nullptr)
{
	create(); // Function call to Create Book List
}

// Function to Create a BookList dynamically
void BookList::create()
{
	ifstream input;
    string categoryfilename=name;
    categoryfilename.append(".txt");
    input.open(categoryfilename);  // Open the Category file
    if(input.fail())
    	{
    		cout<<"Error opening file "<<categoryfilename<<endl;
    	}
    else
    {
    		Book bookobject;
    		input >> bookobject; // Read book information from category file
    		while(!input.fail())
    		{
    			add(bookobject); // Function call to add Book to the BookList
    			input>>bookobject;
    		}
    		input.close();
	}
}

// Add Books to the BookList
//Add Books sorted by ISBN
void BookList::add(const Book & bookobject)
{
	BookNode *booknode= new BookNode(bookobject);
	if(head==nullptr)
	{
	    	head=booknode;
	    	tail=booknode;
	}
	else if (head==tail)
	{
	    if(head->getbook().getisbn()>booknode->getbook().getisbn())
	    {
	    		booknode->setnext(tail);
	    		head=booknode;
	    	}
	    	else if (head->getbook().getisbn()<booknode->getbook().getisbn())
	    	{
	    		head->setnext(booknode);
	    		tail=booknode;
	    	}
	}
	else
	{
	    	BookNode * curr=head;
	    	BookNode *prev=nullptr;
	    	while(curr->getbook().getisbn()<booknode->getbook().getisbn() && curr!=tail)
	    	{
	    		prev=curr;
	    		curr=curr->getnext();
	    	}
	    if(curr==head && curr->getbook().getisbn()!=booknode->getbook().getisbn())
	    	{
	    		booknode->setnext(head);
	    		head=booknode;
	    	}
	    	else if (curr==tail && curr->getbook().getisbn()>booknode->getbook().getisbn())
	    	{
	    		booknode->setnext(tail);
	    		prev->setnext(booknode);
	    	}
	    	else if (curr==tail && curr->getbook().getisbn()<booknode->getbook().getisbn())
	    {
	    		tail->setnext(booknode);
	    		tail=booknode;
	    	}
	    	else if (curr->getbook().getisbn()!=booknode->getbook().getisbn())
	    	{
	    		booknode->setnext(prev->getnext());
	    		prev->setnext(booknode);
	    	}
	}
}

// Merge a BookList with an existing Book List
void BookList::merge(const BookList & booklist)
{
	BookNode *start=booklist.head;
	while(start!=booklist.tail)
	{
		add(start->getbook());
		start=start->getnext();
	}
	add(start->getbook());
}

//Split an existing BookList with Books with Author name starting with A to M
void BookList::splita2m(const BookList & booklist)
{
	BookNode *start=booklist.head;
	string booktitle="";
	while(start!=booklist.tail)
	{
		booktitle=start->getbook().getlastname();
		if(booktitle[0]>='A'&& booktitle[0]<='M')
		{
			add(start->getbook());
		}
		start=start->getnext();
	}
	booktitle=start->getbook().getlastname();
	if(booktitle[0]>='A'&& booktitle[0]<='M')
	{
		add(start->getbook());
	}
}

//Split an existing BookList with Books with Author name starting with N to Z
void BookList::splitn2z(const BookList & booklist)
{
	BookNode *start=booklist.head;
	string booktitle="";
	while(start!=booklist.tail)
	{
		booktitle=start->getbook().getlastname();
		if(booktitle[0]>='N'&& booktitle[0]<='Z')
		{
			add(start->getbook());
		}
		start=start->getnext();
	}
	booktitle=start->getbook().getlastname();
	if(booktitle[0]>='N'&& booktitle[0]<='Z')
	{
		add(start->getbook());
	}
}

//Function to Set Book List name
void BookList::setname (string booklistname)
{
	name=booklistname;
}

//Function to print Book List
void BookList::print()
{
    cout<<"Book list: "<<name<<endl<<endl;;
    cout<<"  ";
    BookNode *end=head;

    Book b;
    int bookcount=0;
    while(end!=nullptr)
    {
    		b=end->getbook();
    		cout<<"Book{"<<b<<"}"<<endl;
    		end=end->getnext();
    		bookcount=bookcount+1;
    		cout<<"  ";
    }
    cout<<"  ("<<bookcount<<" books)"<<endl<<endl;
}

//Destructor for Book List class
BookList::~BookList()
{

}