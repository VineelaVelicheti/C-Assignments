#include<iostream>
#include<fstream>

using namespace std;

#ifndef BOOK_H_
#define BOOK_H_

/**
 * The Book class.
 */

class Book
{
public:

	//Friend function to overload << operator to read Book details
	friend ostream & operator << (ostream & out,Book & bookObject);

	//Friend function to overload >> operator to print Book details
	friend istream & operator >> (istream & in, Book & bookObject);

	//Default Constructor for Book Class
	Book();

	// Parameter Constructor to set the data members
	Book(string isbn,string last,string first,string title);

	// Function to get Book ISBN
	string getisbn() const;

	// Function to get author last name
	string getlastname() const;

	// Function to get author first name
	string getfirstname() const;

	// Function to get Book Title
	string getbooktitle() const;

	//Destructor for Book Class
	~Book();

private:

	string bookisbn; // string variable to store book isbn
	string autlastname; // string variable to store author last name
	string autfirstname; // string variable to store author first name
	string booktitle; // string variable to store book tile

};

#endif /* BOOK_H_ */