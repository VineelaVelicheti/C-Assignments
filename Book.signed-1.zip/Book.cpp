#include <iostream>
#include <string>
#include "Book.h"

using namespace std;

//Default Constructor for the call
Book::Book()
{
	bookisbn=" ";
	autlastname=" ";
	autfirstname=" ";
	booktitle=" ";
}

//initializing all values of the class
Book::Book(string isbn, string last, string first, string title)
{
	bookisbn=isbn;
	autlastname=last;
	autfirstname=first;
	booktitle=title;
}

//overloading extraction operator
//reads command from text file
istream & operator >> (istream & input, Book & bookobject)
{
	getline(input,bookobject.bookisbn,',');
	getline(input,bookobject.autlastname,',');
	getline(input,bookobject.autfirstname,',');
	getline(input,bookobject.booktitle);
	return input;
}

//overloading insertion operator
//prints the book object details to console in desired format
ostream & operator << (ostream & output, Book & bookobject)
{
	cout<< "ISBN="<<bookobject.getisbn();
	cout<<", last="<<bookobject.getlastname();
	cout<<", first="<<bookobject.getfirstname();
	cout<<", title="<<bookobject.getbooktitle();
	return output;
}

/*
**Get functions for all data members of the class.
*/
string Book::getisbn() const {return bookisbn;}
string Book::getlastname() const {return autlastname;}
string Book::getfirstname() const {return autfirstname;}
string Book::getbooktitle() const {return booktitle;}

// Destructor for Book Class
Book::~Book()
{

}