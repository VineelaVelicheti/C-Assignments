#include <string>
#include <fstream>
#include <iostream>
#include <vector>
#include "Book.h"
#include "BookNode.h"
#include "BookList.h"

using namespace std;
const string CATEGORIES_FILE_NAME = "categories.txt";

/**
 * The main. Create and print the book lists.
 */
int main()
{
	ifstream input;
	input.open(CATEGORIES_FILE_NAME);
	if(input.fail())
	{
		cout<<"Error opening file "<<CATEGORIES_FILE_NAME<<endl;
		return -1;
	}
	string bookcategory="";
	vector <string> bookcategories; //string vector to store various book category file names
	vector <BookList> booklist; //BookList vector to create BookList dynamically
	getline(input,bookcategory);

	//Add book categories from CATEGORIES_FILE_NAME to bookcategories vector

	while(!input.fail())
	{
		bookcategories.push_back(bookcategory);
		getline(input,bookcategory);
	}
	input.close();

	// Create various booklist based on the categories
	for (int i=0;i<bookcategories.size();i++)
	{
		booklist.push_back(bookcategories.at(i));
	}
	cout<<endl;

	// Print various book categories
	for (int i=0;i<bookcategories.size();i++)
	{
		booklist.at(i).print();
	}

	BookList mergedlist; // A book list to combine all category books
	mergedlist.setname("MERGED");

	//Merge all book categories
	for(int i=0;i<bookcategories.size();i++)
	{
		mergedlist.merge(booklist.at(i));
	}
	mergedlist.print();
	BookList author_a2m; // Book List to store Books with authors last name starting from A to M
	author_a2m.setname("AUTHORS A-M");
	author_a2m.splita2m(mergedlist);
	author_a2m.print();
	BookList author_n2z;// Book List to store Books with authors last name starting from N to Z
	author_n2z.setname("AUTHORS N_Z");
	author_n2z.splitn2z(mergedlist);
	author_n2z.print();
}