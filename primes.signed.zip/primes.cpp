#include <iostream>
#include <iomanip>

using namespace std;

const int MAX_NUMBER = 1000;  // maximum possible prime number
const int ROW_SIZE   = 20;    // row size for printing

void compute_primes(int numbers_array[]);
void print_primes(int prime_array[]);


/**
 * The main: Compute and print the prime numbers up to MAX_NUMBER.
 */
int main()
{
   int numbers[MAX_NUMBER-1];
   for(int n=0;n<MAX_NUMBER-1;n++)
   	numbers[n]=n+2;
   compute_primes(numbers);
   return 0;
}

//computes the prime numbers
//@param numbers array which has only prime numbers
void compute_primes(int numbers_array[])
{
	int i=0;
	while(i<MAX_NUMBER-1)
	{
	  if(numbers_array[i]>0)
	  {
        int j=i+numbers_array[i];
	  	while(j<MAX_NUMBER-1)
	  	{
	  	 	numbers_array[j]=0;
	  	 	j=j+numbers_array[i];
	  	 }
	   }
	   i++;
	 }

	 print_primes(numbers_array);
}

//prime numbers are printed using this function
//@param array of prime numbers
void print_primes(int prime_array[])
{
 	int row_number=0;
	for(int k=0;k<MAX_NUMBER-1;k++)
	{
		if(prime_array[k]>0)
		{
			if(row_number<ROW_SIZE)
			{
				cout<<setw(3)<<right<<prime_array[k]<<" ";
				row_number=row_number+1;
			}
			else
			{
				cout<<endl;
				cout<<setw(3)<<right<<prime_array[k]<<" ";
				row_number=1;
			}
		}
	}
	cout<<endl<<endl;
	cout<<"Done!";
}