/*
 *  Calculator.h
 *
 *  Created on: Oct 31, 2017
 *      Author: vineevineela
 */

#include <iostream>

using namespace std;

#ifndef CALCULATOR_H_
#define CALCULATOR_H_

class Calculator
{
public:
	//constructor
	Calculator(string str);
	// mutual recursion function to start evaluating the expression
	double expression();
	// to evaluate the term
	double term();
	// to evaluate factor
	double factor();
	// to get result
	double getresult();
	// checks if there is any division by zero
	int isvalid();
private:
	void removespaces();
	string expstr; //input string
	int pos; // position in string
	int valid;// indicates result is valid or not
	double result; // result

};

#endif

