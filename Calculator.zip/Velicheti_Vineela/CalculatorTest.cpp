/*
 * CalculatorTest.cpp
 *
 *  Created on: Oct 31, 2017
 *      Author: vineevineela
 */
#include <iostream>
#include <stdio.h>
#include <sstream>
#include <string>
#include "Calculator.h"

int main()
{
	string str="";
	cout<<"Running calculator Program to perform various arithmetic operations"<<endl<<endl;
	cout<<"Operations allowed are +,-,*,/"<<endl<<endl;
	cout<<"Enter your expression below after the ?"<<endl<<endl;
	cout<<"Provide an = at the end of expression to evaluate it."<<endl<<endl;
	cout<<"To exit the Program please press '.' "<<endl;

	while(true)
	{
		cout<< endl<<"Expression ? ";
		int openbraces=0;
		int closingbraces=0;
		getline(cin,str);
		string exp="";
		if(str.compare(".") ==0)
		{
			cout<<"Done!"<<endl;
			break;
		}
		else
		{
			if(str[str.length()-1]!='=')
			{
				cout<<"Missing = at the end of the String"<<endl;
				continue;
			}
			else if (str.length()>0)
			{
				for (int i=0;i<str.length();i++)
				{
					if( isdigit(str[i]) || str[i]== '='|| str[i]== ' ' || str[i]=='+' || str[i]=='-' || str[i] =='*' || str[i]=='/' || str[i]=='(' || str[i]==')' || str[i]=='.' || str[i]=='e' ||str[i]=='E')
					{
						if(str[i]=='(')
							openbraces=openbraces+1;
						else if (str[i]==')')
							closingbraces=closingbraces+1;
						continue;
					}
					else
					{
						cout<<str.substr(0,i)<<endl;
						cout<<"***** Unexpected ";
						exp=str[i];
						break;
					}
				}
				if(exp!="")
				{
					cout<<exp<<endl;
					continue;
				}
				else if ((openbraces==0 && closingbraces>0) || (openbraces<closingbraces) )
				{
					cout<<" ***** Unexpected )"<<endl;
					continue;
				}
				else if ((openbraces > 0 && closingbraces==0) || (openbraces>closingbraces) )
				{
					cout<<" ***** Missing )"<<endl;
					continue;
				}
				else
				{
					double result;
					Calculator c(str);
					result=c.expression();
					if(c.isvalid())
					{
						cout<<result<<endl;
					}
					else
					{
						cout<<"***** Division by zero"<<endl;
					}
				}
			}
		}


	}
	return 0;

}



