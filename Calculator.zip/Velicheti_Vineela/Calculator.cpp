/*
 * Calculator.cpp
 *
 *  Created on: Oct 31, 2017
 *      Author: vineevineela
 */

#include "Calculator.h"
#include <iostream>
#include <sstream>
#include <string>
using namespace std;

Calculator::Calculator(string exp)
{
	expstr=exp;
	result=0;
	pos=0;
	valid=1;
}
double Calculator::expression()
{
	removespaces();
	//cout<<"Expression called first time "<<endl;
	result=term();
	//cout<<"Expression called second time "<<expstr[pos]<<endl;
    if(expstr[pos]=='+' || expstr[pos]=='-')
    {
    		if(expstr[pos]=='+')
    		{
    			pos=pos+1;
    			result=result+term();
    		}
    		else if(expstr[pos]=='-')
    		{
    			pos=pos+1;
    		    	result=result-term();
    		}
    }
	return result;
}
double Calculator::term()
{
	//cout<<"term called"<<endl;
	double termresult=factor();
	if(expstr[pos]=='*' || expstr[pos]=='/')
	{
		if(expstr[pos]=='*')
		{
			pos=pos+1;
			termresult=termresult*factor();
		}
		else if(expstr[pos]=='/')
		{
			pos=pos+1;
			double den = factor();
			if(den==0)
			{
				valid=0;
			}
			else
				termresult=termresult/den;
		}
	}

	return termresult;
}
double Calculator::factor()
{
	//cout<<"factor called"<<endl;
	double factorresult =0.0;
	if(isdigit(expstr[pos]))
	{
		stringstream ss(expstr.substr(pos));
		ss >> factorresult;
		string temp;
		ss >> temp;
		//cout<<"temp value"<<temp<<endl;
		//cout<<"posvalue before addition"<<pos<<endl;
		pos=expstr.length() - temp.length();
		//cout<<"posvalue after addition"<<pos<<endl;
	}
	else if (expstr[pos]=='(')
	{
		pos=pos+1;
		factorresult= expression();
		pos=pos+1;
	}
	return factorresult;
}
double Calculator::getresult()
{
	return result;
}

void Calculator::removespaces()
{
	expstr.erase(remove(expstr.begin(),expstr.end(),' '),expstr.end());

}
int Calculator::isvalid()
{
	return valid;
}

