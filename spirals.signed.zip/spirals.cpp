#include <iostream>
#include <iomanip>

using namespace std;

const int MAX_SIZE  = 101;  // maximum size of the square matrix
const int MAX_START = 50;   // maximum starting number

void do_spiral(const int n, const int start);
void make_spiral(int n, int[MAX_SIZE][MAX_SIZE], int start);
void print_spiral(int n, int[MAX_SIZE][MAX_SIZE]);

/**
 * The main: Generate and print spirals of various sizes.
 */
int main()
{
   do_spiral(1, 1);
   do_spiral(5, 1);
   do_spiral(9, 11);
   do_spiral(12, 13);
   do_spiral(15, 17);
}

//checks if given startvalue lies between 0 and 50 and odd
//checks if given size is < MAXSIZE
//@param n is size of spiral
//@param start is the start value
void do_spiral(const int n,int start)
{
	cout<<"Spiral of size "<< n <<" starting at "<< start<< endl;

	if(n>MAX_SIZE)
	{
		cout<<"***** Error: Size "<< n <<" must be less than"<<MAX_SIZE<<endl;
		cout<<endl;
	}
	else if(n%2==0)
	{
		cout<<"***** Error: Size "<< n <<" must be odd."<<endl;
		cout<<endl;
	}
	else if (start<1 or start>MAX_START)
	{
		cout<<"***** Error: Start Value "<< start <<" must be between 1 and 50."<<endl;
		cout<<endl;
	}
	if (n<MAX_SIZE && n%2!=0 && start>=1 and start<=50)
	{
        int plain_array[MAX_SIZE][MAX_SIZE];
		make_spiral(n,plain_array,start);
	}
}

// spiral is formed and placed in an array
//@param n is size of spiral
//@param array with maxsize
//@param start value from input
void make_spiral(int n,int spiral_array[MAX_SIZE][MAX_SIZE], int start)
{
	int spiral_value= start;
	int spiral_size=n;
	int max_spiral_value=start+(n*n) -1 ;
	if(spiral_size==1)
		spiral_array[0][0]=spiral_value;
	else
		 {
			int row=(spiral_size-1)/2;
			int col=(spiral_size-1)/2;
			int ini_pos=(spiral_size-1)/2;
			int spiral_loop_count=1;
			int spiral_loop_temp=1;
			spiral_array[row][col]=spiral_value;
			spiral_value=spiral_value+1;
			col=col+1;
			spiral_array[row][col]=spiral_value;
			spiral_value=spiral_value+1;
			while(spiral_value<=max_spiral_value)
			{
				if(col>ini_pos)
				{
					while(spiral_loop_temp!=0)
					{
						row=row-1;
						spiral_array[row][col]=spiral_value;
						spiral_value=spiral_value+1;
						spiral_loop_temp=spiral_loop_temp-1;
					}
					spiral_loop_count=spiral_loop_count+1;
					spiral_loop_temp=spiral_loop_count;
				}

				if(row<col)
				{
					while(spiral_loop_temp!=0)
					{
						col=col-1;
						spiral_array[row][col]=spiral_value;
						spiral_value=spiral_value+1;
						spiral_loop_temp=spiral_loop_temp-1;
					}
					spiral_loop_temp=spiral_loop_count;
				}

				if(row==col and row<ini_pos)
				{
					while(spiral_loop_temp!=0)
					{
						row=row+1;
						spiral_array[row][col]=spiral_value;
						spiral_value=spiral_value+1;
						spiral_loop_temp=spiral_loop_temp-1;
					}
					spiral_loop_temp=spiral_loop_count;
				}

				if(row>col)
				{
					while(spiral_loop_temp!=0)
					{
						col=col+1;
						spiral_array[row][col]=spiral_value;
						spiral_value=spiral_value+1;
						spiral_loop_temp=spiral_loop_temp-1;
					}
					spiral_loop_count=spiral_loop_count+1;
					spiral_loop_temp=spiral_loop_count;
				}

				if(row==col and row>ini_pos)
				{
					if(row<spiral_size-1)
					{
						col=col+1;
						spiral_array[row][col]=spiral_value;
						spiral_value=spiral_value+1;
					}
				}
			}
		 }
	print_spiral(spiral_size,spiral_array);
}

//spiral formed in make spiral is printed in this function
//@param size is passed as n
//@param array of max size is passed
void print_spiral(int n, int spiral_array[MAX_SIZE][MAX_SIZE])
{
	cout<<endl;
	for (int r=0;r<n;r++)
	{
		for(int c=0;c<n;c++)
	    	{
	    		cout<<setw(3)<<right<<spiral_array[r][c]<<" ";
	    	}
	    	cout<<endl;
	}
	cout<<endl;
}