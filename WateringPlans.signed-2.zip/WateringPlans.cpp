/***** #includes here. *****/
#include <iostream>
#include <fstream>
#include <iomanip>
#include <string>

using namespace std;

/***** Define constants here. *****/
const int UNITS_PER_CAN = 3;

/***** Declare functions here. *****/
int plan_near(int plant_count);
int plan_far(int plant_count);
void better_plan(int far_cum_step_units,int near_cum_step_units);

/**
 * The main. For each count of plants, simulate Plan Near and Plan Far,
 * and decide which plan was better.
 */
int main()
{
  /***** Complete this main. *****/
  const string INPUT_FILE_NAME = "counts.txt";
  ifstream input;
  input.open(INPUT_FILE_NAME);
  if (input.fail())
  {
     cout << "Failed to open " << INPUT_FILE_NAME << endl;
     return -1;
  }
  int plant_count;
  // Loop once for each number of plants read from the input file.
  // Stop when the number of plants is 0 or less.
  // During each loop, simulate Plan Near and Plan Far.
  do
  {
     input >> plant_count;
     if(plant_count>0)
     {
        int near_cum_step_units=plan_near(plant_count);
        int far_cum_step_units=plan_far(plant_count);
        cout << endl;
        cout << "*** With " << plant_count << " plants, ";
        better_plan(far_cum_step_units,near_cum_step_units);
     }
  } while (plant_count > 0);
  return 0;
}

/***** Define functions here. *****/
int plan_near(int plant_count)
{
   /* variable declaration*/
   int near_plant_being_watered=0;/*plant being watered*/
   int near_cum_step_units=0; /* near cumulative step units*/
   int near_cum_steps=0; /* near cumulative steps*/
   int near_water_units=UNITS_PER_CAN; /* water in the faucet */
   
   cout << endl;
   cout << "==========================" << endl;
   cout << " Plan Near with " << plant_count << " plants" << endl;
   cout << "==========================" << endl;
   cout << endl;
   cout << "Where      Cum. steps  Water amt.  Cum. step-units" << endl;
   cout << "---------  ----------  ----------  ---------------" << endl;
   // loop continues to calculate cumulative steps ,cumulative step units ,water units until all plants are watered.
   // if water units become 0, and all plants are not watered then control goes to second loop where we go to  faucet and make water units=3 and calculate steps we took to go to faucet.
   while(near_plant_being_watered < plant_count)
   {
      while(near_water_units!=0 && near_plant_being_watered < plant_count)
      {
         near_plant_being_watered=near_plant_being_watered+1;
         near_cum_steps=near_cum_steps+1;
         cout << "Plant  " << near_plant_being_watered << "         ";
         cout << near_cum_steps <<"        " << near_water_units << "           ";
         near_cum_step_units=near_cum_step_units+near_water_units;
         near_water_units=near_water_units-1;
         cout << near_cum_step_units << endl;
      }
      while(near_water_units==0 && near_plant_being_watered < plant_count)
      {
         cout << "FAUCET"<< "           ";
         near_cum_step_units=near_cum_step_units+(near_cum_steps*near_water_units);
         near_cum_steps=near_cum_steps+near_plant_being_watered;
         cout << near_cum_steps <<"        " << near_water_units << "           ";
         cout << near_cum_step_units << endl;
         near_water_units=UNITS_PER_CAN;
      }
      near_cum_steps=near_cum_steps+ near_plant_being_watered;
      near_cum_step_units= near_cum_step_units+near_plant_being_watered*near_water_units;
   }
   // display the final values when we reach faucet after watering all plants.
   cout << "FAUCET"<< "           ";
   cout << near_cum_steps <<"        " << near_water_units << "           ";
   cout << near_cum_step_units << endl;
   cout << endl;
   cout << "Plan Near: Total steps = " << near_cum_steps << ", total step-units = " << near_cum_step_units << endl;
   return near_cum_step_units;
}

int plan_far(int plant_count)
{  
   /* variable declaration */
   int far_plant_being_watered=plant_count;/* plant being watered= plant count */
   int far_cum_step_units=0;/* far cumulative step units*/
   int far_cum_steps=0;/* far cumulative steps*/
   int far_water_units=UNITS_PER_CAN; /* water in the faucet */
   
   cout << endl;
   cout << "==========================" << endl;
   cout << " Plan Far with " << plant_count << " plants" << endl;
   cout << "==========================" << endl;
   cout << endl;
   cout << "Where      Cum. steps  Water amt.  Cum. step-units" << endl;
   cout << "---------  ----------  ----------  ---------------" << endl;
   
   // loop shouldn’t stop unless water units become 0 and watering all plants is finished
   while(far_water_units!=0 && far_plant_being_watered!=0)
   {
      if(far_cum_steps==0)
      {
         far_cum_steps=far_cum_steps+ far_plant_being_watered;
         far_cum_step_units= far_cum_step_units+ far_plant_being_watered*far_water_units;
         cout << "Plant  " << far_plant_being_watered << "         ";
         cout << far_cum_steps <<"          " << far_water_units << "            ";
         cout << far_cum_step_units << endl;
      }
      else if(far_cum_steps!=0)
      {
         far_cum_steps=far_cum_steps+1;
         far_cum_step_units=far_cum_step_units+far_water_units;
         cout << "Plant  " << far_plant_being_watered << "         ";
         cout << far_cum_steps <<"          " << far_water_units << "            ";
         cout << far_cum_step_units << endl;
      }
      far_water_units=far_water_units-1;
      far_plant_being_watered=far_plant_being_watered-1;
      // condition when water units become 0 and plants to water are still left
      while(far_water_units==0 && far_plant_being_watered!=0)
      {
         far_cum_steps=far_cum_steps+far_plant_being_watered+1;
         far_cum_step_units=far_cum_step_units+ (far_plant_being_watered+1)* far_water_units;
         cout << "FAUCET"<< "           ";
         cout << far_cum_steps <<"          " << far_water_units << "            ";
         cout << far_cum_step_units << endl;
         far_water_units=UNITS_PER_CAN;
         far_cum_steps=far_cum_steps+far_plant_being_watered;
         far_cum_step_units=far_cum_step_units+far_plant_being_watered*far_water_units;
         cout << "Plant  " << far_plant_being_watered << "         ";
         cout << far_cum_steps <<"          " << far_water_units << "            ";
         cout << far_cum_step_units << endl;
         far_water_units=far_water_units-1;
         far_plant_being_watered=far_plant_being_watered-1;
      }
      // condition when we finish watering all plants
      while(far_plant_being_watered==0)
      {
         far_cum_steps=far_cum_steps+1;
         far_cum_step_units=far_cum_step_units+far_water_units;
         cout << "FAUCET"<< "           ";
         cout << far_cum_steps <<"          " << far_water_units << "            ";
         cout << far_cum_step_units << endl;
         break;
      }
   }
   cout << endl;
   cout << "Plan Far: Total steps = " << far_cum_steps << ", total step-units = " << far_cum_step_units << endl;
   return far_cum_step_units;
}
void better_plan(int far_cum_step_units,int near_cum_step_units)
{
   if(far_cum_step_units > near_cum_step_units)
   {
      cout << "Plan Near is better with " << far_cum_step_units-near_cum_step_units << " fewer step-units." << endl;
   }
   else if(far_cum_step_units < near_cum_step_units)
   {
      cout << "Plan Far is better with " << near_cum_step_units-far_cum_step_units << " fewer step-units." << endl;
   }
   else
   {
      cout << "Both Plans result in " << far_cum_step_units << " step-units." << endl;
   }
}