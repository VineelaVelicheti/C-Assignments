#include "ShellSortOptimal.h"
#include "VectorSorter.h"

/**
 * Constructor.
 * @param name the name of this algorithm.
 */
ShellSortOptimal::ShellSortOptimal(string name) :VectorSorter(name) {}

/**
 * Destructor.
 */
ShellSortOptimal::~ShellSortOptimal() {}

/**
 * Run the optimal shellsort algorithm.
 * According to Don Knuth:
 * h = 3*i + 1 for i = 0, 1, 2, ... used in reverse.
 * @throws an exception if an error occurred.
 */
void ShellSortOptimal::run_sort_algorithm() throw (string)
{
    /***** Complete this member function. *****/
	// Reference from www.thecrazyprogrammer.com
    int h=0;
	while((3*h+1)<size)
	{
		h=3*h+1;
	}
	while(h>0)
	{
		for(int i=h;i<size;i++)
		{
			Element smallest=data[i];
			int j=i;
			compare_count++;
			int temp=0;
			while(j>=h && data[j-h]>smallest)
			{
				data[j]=data[j-h];
				move_count++;
				j=j-h;
				temp++;
			}
			data[j]=smallest;
			compare_count=compare_count+temp;
		}
		h=(h-1)/3;
	}
}