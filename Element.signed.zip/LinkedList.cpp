#include <iostream>
#include "LinkedList.h"
using namespace std;

/**
 * Default constructor.
 */
LinkedList::LinkedList() : head(nullptr), tail(nullptr), size(0) {};

/**
 * Constructor: Create a new list from an existing one.
 * Both lists will share the nodes.
 * @param head the head of the existing list.
 * @param tail the tail of the existing list.
 * @param size the size of the existing list.
 */
LinkedList::LinkedList(Node *head, Node *tail, const int size)
{
    this->head = head;
    this->tail = tail;
    this->tail->next = nullptr;

    this->size = size;
}

/**
 * Destructor.
 */
LinkedList::~LinkedList() {}

/**
 * Get the head of the list.
 * @return the head.
 */
Node *LinkedList::get_head() const { return head; }

/**
 * Get the tail of the list.
 * @return the tail.
 */
Node *LinkedList::get_tail() const { return tail; }

/**
 * Get the size of the list.
 * @return the size.
 */
int LinkedList::get_size() const { return size; }

/**
 * Set the head, tail, and size of the linked list.
 * @param head the head of the linked list.
 * @param tail the tail of the linked list.
 * @param size the size of the linked list.
 */
void LinkedList::set(Node *head, Node *tail, int size)
{
    this->head = head;
    this->tail = tail;
    this->tail->next = nullptr;
    this->size = size;
}

/**
 * Remove the head of the list and return the removed node.
 * @return the removed node.
 */
Node *LinkedList::remove_head()
{
    if (head == nullptr) return nullptr;

    Node *removed_head = head;
    head = head->next;

    // Is the list now empty?
    if (head == nullptr) tail = nullptr;

    size--;
    return removed_head;
}

/**
 * Add a node to the tail of the list.
 * @param value the value of the node to add.
 */
void LinkedList::add(const Element& elmt)
{
    Node *node = new Node(elmt);
    add(node);
}

/**
 * Add a node to the tail of the list.
 * @param node the node to add.
 */
void LinkedList::add(Node *node)
{
    // First node.
	if (head == nullptr)
    {
    	    head = tail = node;
    }

    // Subsequent node.
    else
    {
    	    tail->next = node;
        tail = node;
    }

    node->next = nullptr;
    size++;
 }

/**
 * Delete all the nodes of the list.
 */
void LinkedList::clear()
{
    // Repeatedly delete the head node until the list is empty.
    while (head != nullptr)
    {
        Node *next = head->next;
        delete head;
        head = next;
    }

    tail = nullptr;
    size = 0;
}

/**
 * Reset the head, tail, and size of the list.
 */
void LinkedList::reset()
{
    head = tail = nullptr;
    size = 0;
}

/**
 * Print the values of the list's nodes.
 */
void LinkedList::print() const
{
    for (Node *ptr = head; ptr != nullptr; ptr = ptr->next)
    {
        cout << " " << ptr->element.get_value();
    }
    cout << endl;
}

/**
 * Split this list into two sublists.
 * @param list1 the first sublist.
 * @param list2 the second sublist.
 */
void LinkedList::split(LinkedList& list1, LinkedList& list2)
{
    /***** Complete this member function. *****/
	Node *temp=head;
	if(temp==nullptr ||temp->next==nullptr)
		return;
	list1.head=temp;
	list1.tail=temp;
	list1.size=list1.size+1;
	
	list2.head=temp->next;
	list2.tail=temp->next;
	list2.size=list2.size+1;
	
	temp=temp->next;
	while(temp!=nullptr && temp->next!=nullptr)
	{
		//cout<<"In Linked list loop"<<endl;
		Node * temp2=temp->next;
		if(list1.head==list1.tail)
		{
			list1.head->next=temp2;
			list1.tail=temp2;
			list1.size=list1.size+1;
		}
		else
		{
			list1.tail->next=temp2;
			list1.tail=temp2;
			list1.size=list1.size+1;
		}
		if (temp2 != nullptr && temp2->next != nullptr)
		{
			temp2=temp->next->next;
			if(list2.head==list2.tail)
			{
				list2.head->next=temp2;
				list2.tail=temp2;
				list2.size=list2.size+1;
			}
			else
			{
				list2.tail->next=temp2;
				list2.tail=temp2;
				list2.size=list2.size+1;
			}
		}
		temp=temp2;

	}

	list1.tail->next=nullptr;
	list2.tail->next=nullptr;
}

/**
 * Add another list to the end of this list.
 * @param other_list the other list.
 */
void LinkedList::concatenate(LinkedList& other_list)
{
    /***** Complete this member function. *****/

	if(head==nullptr && other_list.get_head() !=nullptr)
	{
		head=other_list.get_head();
		tail=other_list.get_head();
		return;
	}
	else if(other_list.get_head() ==nullptr)
	{
			return;
	}
	else if(other_list.size==1)
	{

		if(other_list.get_head()->element.get_value()< head->element.get_value())
		{
			other_list.get_head()->next=head;
			head=other_list.get_head();
		}
		else if(other_list.get_head()->element.get_value()>head->element.get_value() && other_list.get_head()->element.get_value()< tail->element.get_value())
		{
		Node *p=head;
		Node *prev=new Node();
		Node *q=other_list.get_head();
	    while( p!=nullptr && q->element.get_value()>p->element.get_value())
		{
	    	    prev=p;
			p=p->next;
		}
		prev->next=q;
		q->next=p;
        return;
		}
		else
		{
			Node *q=other_list.get_head();
			tail->next= q;
			tail=q;
		}
	}
	else if(other_list.size>1)
	{
		Node *p=other_list.get_head();

		while(p!=nullptr)
		{
		Node *q=head;
		while(p>q)
		{
			q=q->next;
		}
		head->next=p;
		p->next=q;
		p=p->next;
		}
	}
}