#include "QuickSortOptimal.h"
#include "QuickSorter.h"
#include "Element.h"

/**
 * Constructor.
 * @param name the name of this algorithm.
 */
QuickSortOptimal::QuickSortOptimal(string name) : QuickSorter(name) {}

/**
 * Destructor.
 */
QuickSortOptimal::~QuickSortOptimal() {}

/**
 * Choose a good pivot, the median-of-three:
 * The middle value of the leftmost, rightmost, and center elements.
 * This is a compromise since the most optimal pivot would be the
 * median of the subrange, but that's too expensive to compute.
 * @param left the left index of the subrange to sort.
 * @param right the right index of the subrange to sort.
 * @return the chosen pivot value.
 */
Element& QuickSortOptimal::choose_pivot_strategy(const int left, const int right)
{
	int middle_pos= (left+right)/2;
	long start=data[left].get_value();
	long end=data[right].get_value();
	long mid=data[middle_pos].get_value();
	long temp;
	if(start>end)
	{
		temp=start;
		start=end;
		end=temp;
	}
	if(start>mid)
	{
		temp=start;
		start=mid;
		mid=temp;
	}
	if(mid>end)
	{
		temp=mid;
		mid=end;
		end=temp;
	}

	if(data[left].get_value()==mid)
	{
		//cout<<"pivot is "<< data[left].get_value()<< endl;
		compare_count++;
		swap(left,right);

		return data[right];
	}
	else if(data[middle_pos].get_value()==mid)
	{
		compare_count++;
		//cout<<"pivot is "<< data[middle_pos].get_value()<< endl;
		swap(middle_pos,right);
		return data[right];
	}
	else
	{
		compare_count++;
		//cout<<"pivot is "<< data[right].get_value()<< endl;
		return data[right];
	}
}