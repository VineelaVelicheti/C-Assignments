#include "InsertionSort.h"
#include "VectorSorter.h"
#include <string>


/**
 * Constructor.
 * @param name the name of the algorithm.
 */

InsertionSort::InsertionSort(string name) : VectorSorter(name) {}

/**
 * Destructor.
 */
InsertionSort::~InsertionSort() {}

/**
 * Run the insertion sort algorithm.
 * @throws an exception if an error occurred.
 */
void InsertionSort::run_sort_algorithm() throw (string)
{
    /***** Complete this member function. *****/

	// Reference from GeeksforGeeks
	for (int curr=1;curr<size;curr++)
	{
		Element smallest=data[curr];
		int prev=curr-1;
		compare_count++;

		while(prev>=0 && data[prev] >smallest)
		{
			data[prev+1]=data[prev];
			prev=prev-1;
			move_count++;
		}
		compare_count=compare_count+ curr-prev;
		data[prev]=smallest;
	}
}
