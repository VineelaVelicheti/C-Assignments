#include <iostream>
#include "Element.h"

using namespace std;

/***** Complete this class. *****/

/**
 * Default constructor.
 */
Element::Element() : value(0) {}

/**
 * Constructor.
 * @param val the element's value.
 */
Element::Element(long val) : value(val) {}

/**
 * Copy constructor.
 * @param other the other element to be copied.
 */
Element::Element(const Element& other)
{
    /***** Complete this class. *****/
	copy_count=copy_count+1;
	value=other.value;
}

/**
 * Destructor.
 */
Element::~Element()
{
    /***** Complete this class. *****/
	dest_count=dest_count+1;
}

/**
 * Getter.
 * @return the value.
 */
long Element::get_value() const { return value; }

long Element::get_copy_count ()  {return copy_count ;}
long Element::get_destructor_count()  { return dest_count;}
void Element::reset() { copy_count=0;dest_count=0;}

bool operator < (const Element & e1, const Element &e2)
{
	return e1.get_value()<e2.get_value();
}

bool operator > (const Element & e1, const Element &e2)
{
	return e1.get_value()>e2.get_value();
}

ostream &operator << (ostream & out, const Element & e)
{
	out<<e.get_value();
	return out;
}

long Element::copy_count=0;
long Element::dest_count=0;