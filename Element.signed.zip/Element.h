#ifndef DATA_H_
#define DATA_H_

#include <iostream>
using namespace std;

/**
 * The class for the data elements that will be sorted.
 */
class Element
{
public:
	friend bool operator < (const Element & e1, const Element & e2);
	friend bool operator > (const Element & e1, const Element & e2);
	friend ostream &operator << (ostream & out, const Element & e);

    Element();
    Element(long val);
    Element(const Element& other);
    virtual ~Element();

    long get_value() const;

    /***** Complete this class. *****/

    static long get_copy_count () ;
    static long get_destructor_count() ;
    static void reset();
private:
    long value;
    static long copy_count;
    static long dest_count;
};

#endif /* DATA_H_ */