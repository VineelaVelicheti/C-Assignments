#include "ShellSortSuboptimal.h"

/**
 * Constructor.
 * @param name the name of this algorithm.
 */
ShellSortSuboptimal::ShellSortSuboptimal(string name) : VectorSorter(name) {}

/**
 * Destructor.
 */
ShellSortSuboptimal::~ShellSortSuboptimal() {}

/**
 * Run the suboptimal shellsort algorithm.
 * @throws an exception if an error occurred.
 */
void ShellSortSuboptimal::run_sort_algorithm() throw (string)
{
    /***** Complete this member function. *****/
	// Referred from www.thecrazyprogrammer.com
	int h=size/2;
	while(h>0)
	{
		for(int i=h;i<size;i++)
		{
			Element smallest=data[i];
			int j=i;
			compare_count++;
			int temp=0;
			while(j>=h && data[j-h]>smallest)
			{
				data[j]=data[j-h];
				move_count++;
				j=j-h;
				temp++;
			}
			data[j]=smallest;
			compare_count=compare_count+temp;
		}
		h=h/2;
	}
}