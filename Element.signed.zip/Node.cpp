#include "Node.h"
#include "Element.h"

/***** Complete this class. *****/

Node::Node()
{
	next=nullptr;

}
Node::Node(Element elmt)
{
	element=elmt;
	next=nullptr;
}
Node::~Node()
{

}