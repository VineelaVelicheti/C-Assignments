
#include <string>
#include "SortedVector.h"
#include "SortedList.h"
#include "Node.h"

using namespace std;

// How many times to do gets.
const int GETS_COUNT = 10000;

//Function to create a vector of given size and add elements at the start of the vector
void vector_prepends(SortedVector& sv, const int size)
{
    for(int i=size-1;i>=0;i--)
    {
    		sv.prepend(i); // Function call to vector prepend
    }
}
//Function to create a list of given size and add elements at the start of the list
void list_prepends(SortedList& sl, const int size)
{
	for(int i=size-1;i>=0;i--)
	{
	    		sl.prepend(i);// Function call to list prepend
	}
}

//Function to create a vector of given size and add elements at the end of the vector
void vector_appends(SortedVector& sv, const int size)
{
	for(int i=0;i<size;i++)
	{
		sv.append(i);// Function call to vector append
	}
}

//Function to create a list of given size and add elements at the end of the list
void list_appends(SortedList& sl, const int size)
{
	for(int i=0;i<size;i++)
	{
		sl.append(i); // Function call to list append
	}
}

//Function to create a vector of given size and get elements at random position
void vector_gets(SortedVector& sv, const int size) throw (string)
{
    // First fill the vector data.
    vector_appends(sv, size);
    Node::reset();

    // Loop to access nodes at random positions.
    for (int i = 0; i < GETS_COUNT; i++)
    {
        int index = rand()%sv.size(); // Generate a random index position to retrieve the data

        long value = sv.at(index).get_value();

       //  Complete this function.

        // Make sure we got the correct node.
        if (index != value) throw string("Vector data mismatch!");
    }
}

//Function to create a list of given size and get elements at random position
void list_gets(SortedList& sl, const int size) throw (string)
{
    // First fill the list data.
    list_appends(sl, size);
    Node::reset();

    // Loop to access nodes at random positions.
    for (int i = 0; i < GETS_COUNT; i++)
    {
        int index = rand()%sl.size(); // Generate a random index position to retrieve the data
        long value = sl.at(index).get_value();

       // Complete this function.

        // Make sure we got the correct node.
        if (index != value) throw string("List data mismatch!");
    }
}

//Function to remove all elements from a vector one by one
void vector_removes(SortedVector& sv, const int size)
{
    // First fill the vector data.
    vector_appends(sv, size);
    Node::reset();

    // Loop to remove a node at a random position
    // one at a time until the nodes are all gone.
    while (sv.size() > 0)
    {
        int index = rand()%sv.size(); // Generate a random index position to remove from the vector
        sv.remove(index);
    }
}

//Function to remove all elements from a list one by one
void list_removes(SortedList& sl, const int size)
{
    // First fill the list data.
    list_appends(sl, size);
    Node::reset();

    while (sl.size() > 0)
    {
    		int index = rand()%sl.size(); // Generate a random index position to remove from the vector
    	    sl.remove(index);
    }
}

//Function to insert elements with random values to a vector
void vector_inserts(SortedVector& sv, const int size)
{
	for(int i=0;i<size;i++)
	{
		sv.insert(rand());
	}
}
//Function to insert elements with random values to a list
void list_inserts(SortedList& sl, const int size)
{
	for(int i=0;i<size;i++)
	{
		sl.insert(rand());
	}
}



