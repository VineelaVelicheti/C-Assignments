
#include <iostream>
#include <iterator>
#include "SortedVector.h"

using namespace std;

//Default constructor for Sorted Vector Class
SortedVector::SortedVector()
{
    Node::reset(); // Call to reset Static function to reset the counters
}

//Default Destructor for Sorted Vector Class
SortedVector::~SortedVector()
{
    Node::reset();// Call to reset Static function to reset the counters
}

// Function to Get the size of the vector
int SortedVector::size() const { return data.size(); }

// Function to check if the vector is in sorted order or not
bool SortedVector::check() const
{
    if (data.size() == 0) return true;

    vector<Node>::const_iterator it = data.begin();
    vector<Node>::const_iterator prev = it;

    it++;

    // Ensure that each node is greater than the previous node.
    while ((it != data.end()) && (*it > *prev))
    {
        prev = it;
        it++;
    }

    return it == data.end();  // Good if reached the end.
}

// Function to add elements at the start of vector
void SortedVector::prepend(const long value)
{
	Node n(value);
	data.insert(data.begin(),n);

}

// Function to add elements at the end of vector
 void SortedVector::append(const long value)
{
	 Node n(value);
	 data.insert(data.end(),n);
}

 // Function to remove elements at given vector index
void SortedVector::remove(const int index)
{
	data.erase(data.begin()+index);
}

// Function to insert elements at a position and ensuring the vector is in sorted order
void SortedVector::insert(const long value)
{
	Node n(value);
	if(data.size()==0)
		data.push_back(n);
	else
	{
		vector <Node>::iterator iter=data.begin();
		while(iter->get_value()<value && iter!=data.end())
		{
			advance(iter,1);
		}
		if(iter==data.end())
			data.push_back(n);
		else
			data.insert(iter,n);
	}

}

//Function to get the Node at the given index postion
Node SortedVector::at(const int index) const
{
	return data.at(index);
}



