
#include <iostream>
#include <iterator>
#include "SortedList.h"

using namespace std;

// Default Constructor for Sorted List class
SortedList::SortedList()
{
    Node::reset();
}

// Default Destructor for Sorted List class
SortedList::~SortedList()
{
    Node::reset();
}

// Function to get the size of the list
int SortedList::size() const { return data.size(); }

// Function to check list sort Order
bool SortedList::check()
{
    if (data.size() == 0) return true;

    list<Node>::iterator it = data.begin();
    list<Node>::iterator prev = it;

    it++;

    // Ensure that each node is greater than the previous node.
    while ((it != data.end()) && (*it > *prev))
    {
        prev = it;
        it++;
    }

    return it == data.end();  // Good if reached the end.
}
// Function to add elements at the start of List
void SortedList::prepend(const long value)
{
	Node n(value);
	data.insert(data.begin(),n);
}

// Function to add elements at the end of list
void SortedList::append(const long value)
{
	 Node n(value);
	 data.insert(data.end(),n);
}

// Function to remove elements at given List index
void SortedList::remove(const int index)
{

	list<Node>::iterator iter =data.begin() ;
	advance(iter,index);
	data.erase(iter);
}

// Function to insert elements at a position and ensuring the list is in sorted order
void SortedList::insert(const long value)
{

	Node n(value);
	if(data.size()==0)
		data.push_back(n);
	else
	{
		list <Node>::iterator iter=data.begin();
		while(iter->get_value()<value && iter!=data.end())
		{
			advance(iter,1);
		}
		if(iter==data.end())
			data.push_back(n);
		else
			data.insert(iter,n);
	}
}

//Function to get the Node at the given index postion
Node SortedList::at(const int index)
{
	int size=data.size();
	if(index< size/2) // Based on the size of vector use either the forward iterator or reverse iterator
	{
		list<Node>::iterator iter =data.begin() ;
		advance(iter,index);
		return *iter;
	}
	else
	{
		list<Node>::reverse_iterator iter =data.rbegin() ;
		advance(iter,size-index-1);
		return *iter;
	}

}



