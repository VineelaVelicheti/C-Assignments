#include <iostream>
#include <iomanip>
#include <vector>
using namespace std;

const int MAX_START = 50;   // maximum starting number

void do_prime_spiral(const int n, const int start); // Function to specify the size and start value for Spiral
void make_prime_spiral(const int n, const int start); // Function to create a Spiral and a Prime Vector
vector <int>  make_prime_vector(const int n, const int start); // Function to create a prime vector
void print_prime_spiral(vector<vector<int> >,const int n, vector <int>, int prime_count); // Function to Print the desired output
/**
 * The main: Generate and print prime spirals of various sizes.
 */
int main()
{
    do_prime_spiral(5, 1);
    do_prime_spiral(25, 11);
    do_prime_spiral(35, 0);
    do_prime_spiral(50, 31);
    do_prime_spiral(101, 41);
}

// Function do Prime Spiral
// It checks whether the Size of Spiral and the Start value are valid or not and later calls the make prime spiral function
//@param n is the size of array
//@param start is the start value of spiral
void do_prime_spiral(const int n,int start)
{
	cout<<"Prime spiral of size "<<n<<" starting at "<< start<< endl;
	if(n%2==0)
	{
		cout<<"***** Error: Size "<< n <<" must be odd."<<endl;
		cout<<endl;
	}
	else if (start<1 || start>MAX_START)
	{
		cout<<"***** Error: Starting Value "<< start <<" < 1 or > "<< MAX_START<<endl;
		cout<<endl;
	}
	if (n%2!=0 && start>=1 && start<=MAX_START)
	{
		make_prime_spiral(n,start);
	}
}

// Make Prime Spiral function
// Used for creating a Spiral in Counter Clockwise direction
// Internally calls Make Prime vector function which returns a prime vector
// Once the Prime Spiral is created it calls the function print prime spiral to print the desired output
//@param n is size of spiral
//@param start is the start value of spiral
void make_prime_spiral(const int n,int start)
{
	 vector<vector<int> > prime_spiral (n,vector<int>(n));
	 int spiral_size= n;
	 int spiral_value=start;
	 int max_spiral_value=start+(n*n) -1 ;
	 vector <int> prime_vector =make_prime_vector(n,start); // Creates a Prime Vector by calling make_prime_vector function
	 int total_primes=prime_vector.size();

	 // Make Spiral
	 if(spiral_size==1)
		 prime_spiral[0][0]=spiral_value;
	 else
	 {
		int row=(spiral_size-1)/2; // variable for populating rows in vector
		int col=(spiral_size-1)/2; // variable for populating columns in vector
		int ini_pos=(spiral_size-1)/2; // temporary variable to store the initial start point for the spiral
		int spiral_loop_count=1;
		int spiral_loop_temp=1;
		prime_spiral[row][col]=spiral_value;
		spiral_value=spiral_value+1;
		col=col+1;
		prime_spiral[row][col]=spiral_value;
		spiral_value=spiral_value+1;
		while(spiral_value<=max_spiral_value)
		{
			if(col>ini_pos)
			{
				while(spiral_loop_temp!=0)
				{
					row=row-1;
					prime_spiral[row][col]=spiral_value;
					spiral_value=spiral_value+1;
					spiral_loop_temp=spiral_loop_temp-1;
				}
				spiral_loop_count=spiral_loop_count+1;
				spiral_loop_temp=spiral_loop_count;
			}

			if(row<col)
			{
				while(spiral_loop_temp!=0)
				{
					col=col-1;
					prime_spiral[row][col]=spiral_value;
					spiral_value=spiral_value+1;
					spiral_loop_temp=spiral_loop_temp-1;
				}
				spiral_loop_temp=spiral_loop_count;
			}

			if(row==col and row<ini_pos)
			{
				while(spiral_loop_temp!=0)
				{
					row=row+1;
					prime_spiral[row][col]=spiral_value;
					spiral_value=spiral_value+1;
					spiral_loop_temp=spiral_loop_temp-1;
				}
				spiral_loop_temp=spiral_loop_count;
			}

			if(row>col)
			{
				while(spiral_loop_temp!=0)
				{
					col=col+1;
					prime_spiral[row][col]=spiral_value;
					spiral_value=spiral_value+1;
					spiral_loop_temp=spiral_loop_temp-1;
				}
				spiral_loop_count=spiral_loop_count+1;
				spiral_loop_temp=spiral_loop_count;
			}

			if(row==col and row>ini_pos)
			{
				if(row<spiral_size-1)
				{
					col=col+1;
					prime_spiral[row][col]=spiral_value;
					spiral_value=spiral_value+1;
				}
			}

		}
	 }

	 print_prime_spiral(prime_spiral,n,prime_vector,total_primes);

}

vector<int> make_prime_vector(const int n, const int start)
{
	vector <int> prime_vector;
	vector <int> number_vector;
	int max_spiral_value =start +(n*n) -1;
	int total_primes=0;
	for (int i=0; i<max_spiral_value-1;i++)
	{
		number_vector.resize(number_vector.size() + 1);
		number_vector[i]= i+2;
	}
	 // Update the composite numbers in the temporary vector to 0 using Sieve of Eratosthenes logic
	for(int i=0;i<max_spiral_value-1;i++)
	{
		if(number_vector[i]>0)
		{
			int j=i+number_vector[i];
			while(j<max_spiral_value-1)
			{
				number_vector[j]=0;
				j=j+number_vector[i];
			}
		}
	}

	// Generate the Prime vector with the list of non zero values from the temporary number vector
	// Identify the total list of Prime numbers in the vector
	for(int i=0; i< number_vector.size();i++)
	{
		if(number_vector[i]!=0)
		{
			prime_vector.resize(prime_vector.size() + 1);
			prime_vector[total_primes]=number_vector[i];
			total_primes=total_primes+1;
		}
	 }
	 return prime_vector;
}


// Print Prime Spiral function
// Function to print the output in the desired format
// Compare each value in Spiral Vector with values in Prime Vector
// For each spiral vector value print '#' if the corresponding value is in Prime Vector if not print "."
//@param vector of spiral
//@param n is size
//@param vector of prime numbers
//@param prime count is the size of prime spiral
void print_prime_spiral(vector<vector<int> > spiral,const int n, vector <int> prime, int prime_count)
{
	cout<<endl;
	for (int r=0;r<n;r++)
	{
		for(int c=0;c<n;c++)
		{
			int is_prime=0;
		    for(int k=0;k<prime_count;k++)
		    		if(spiral[r][c]==prime[k])
		    			is_prime=1;
		    if(is_prime==1)
		    		cout<<"#";
		    else
		    		cout<<".";
		 }
		 cout<<endl;
	}
	cout<<endl;
}

