/*
 * AvlTree.cpp
 *
 *  Created on: Nov 24, 2017
 *      Author: vineevineela
 */


#include <iostream>
#include "AvlTree.h"

using namespace std;

AvlTree::AvlTree()
    : BinarySearchTree()
{
	avl_probe_count=0;
	avl_comparison_count=0;
}

AvlTree::~AvlTree()
{
}

int AvlTree::height(const BinaryNode *ptr)
{
    return ptr == nullptr ? -1 : ptr->height;
}

void AvlTree::insert(const long data, BinaryNode* &ptr)
{
    BinarySearchTree::insert(data, ptr);
    rebalance(ptr);
}

void AvlTree::remove(const long data, BinaryNode* &ptr)
{
    BinarySearchTree::remove(data, ptr);
    rebalance(ptr);
}

BinaryNode *AvlTree::rebalance(BinaryNode* &ptr)
{
//    cout << "=== Rebalance called on "
//         << (ptr != nullptr ? to_string(ptr->data) : "null")
//         << endl;

    /***** Complete this function. *****/

    // Recompute the node's height.

	avl_probe_count++;
    if (ptr == nullptr) return ptr;

    // Left side too high.
    if (height(ptr->left) - height(ptr->right) > 1)
    {
    		avl_comparison_count++;
        if (height(ptr->left->left)>= height(ptr->left->right))
        {
        		 ptr = singleRightRotation(ptr);
        }
        else
        {
             ptr = doubleLeftRightRotation(ptr);
        }
     }
     // Right side too high.
     else if (height(ptr->right) - height(ptr->left) > 1)
     {
    	 avl_comparison_count++;
       if (height(ptr->right->right)>= height(ptr->right->left))
       {

            ptr = singleLeftRotation(ptr);
        }
        else
        {
        		ptr = doubleRightLeftRotation(ptr);
        }
      }
    // Recompute the node's height.
    	ptr->height = (max(height(ptr->left),height(ptr->right)) + 1);

    	if (checkBalance(ptr) < 0)
    {
        cout << endl << "***** Tree unbalanced!" << endl;
    }
    return ptr;

}

BinaryNode *AvlTree::singleRightRotation(BinaryNode *k2)
{
    /***** Complete this function. *****/
	BinaryNode *x = k2->left;
	BinaryNode *T2 = x->right;
	avl_probe_count=avl_probe_count+2;

	// Perform rotation
	x->right = k2;
	k2->left = T2;

	// Update heights
	k2->height = max(height(k2->left), height(k2->right))+1;
	x->height = max(height(x->left), height(x->right))+1;

	// Return new root
	return x;
}

BinaryNode *AvlTree::doubleLeftRightRotation(BinaryNode *k3)
{
    /***** Complete this function. *****/
	k3->left =  singleLeftRotation(k3->left);
	return singleRightRotation(k3);
}

BinaryNode *AvlTree::doubleRightLeftRotation(BinaryNode *k1)
{
    /***** Complete this function. *****/
	k1->right = singleRightRotation(k1->right);
	return singleLeftRotation(k1);
}

BinaryNode *AvlTree::singleLeftRotation(BinaryNode *k1)
{
    /***** Complete this function. *****/
	BinaryNode *y = k1->right;
	BinaryNode *T2 = y->left;

	avl_probe_count=avl_probe_count+2;
	// Perform rotation
	y->left = k1;
	k1->right = T2;

    //  Update heights
	k1->height = max(height(k1->left), height(k1->right))+1;
	y->height = max(height(y->left), height(y->right))+1;

	// Return new root
	return y;
}

int AvlTree::checkBalance(BinaryNode *ptr)
{
    if (ptr == nullptr) return -1;

    int leftHeight  = checkBalance(ptr->left);
    int rightHeight = checkBalance(ptr->right);

    if ((abs(height(ptr->left) - height(ptr->right)) > 1)
        || (height(ptr->left)  != leftHeight)
        || (height(ptr->right) != rightHeight))
    {
        return -2;       // unbalanced
    }

    return height(ptr);  // balanced
}


