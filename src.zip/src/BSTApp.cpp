/*
 * BSTApp.cpp
 *
 *  Created on: Nov 24, 2017
 *      Author: vineevineela
 */

/**
 * Test the binary search tree and AVL tree implementations.
 * The AVL tree is derived from the binary search tree.
 *
 * Create a tree of height 5 and then repeatedly
 * delete the root. The AVL tree should remain balanced
 * after each node insertion and deletion.
 *
 * Author: Ron Mak
 *         Department of Computer Engineering
 *         San Jose State University
 */
#include <iostream>
#include <iomanip>
#include <vector>
#include <stdlib.h>
#include <array>
#include <time.h>
#include <ctime>
#include <chrono>


#include "BinarySearchTree.h"
#include "AvlTree.h"

using namespace std;
using namespace std::chrono;

static const long VALUES[] = {5000,10000,15000,20000,25000,30000,35000,40000,45000,50000};

void build_tree(BinarySearchTree& tree,vector<long> n);
void search_tree(BinarySearchTree& tree,vector<long> n);
/**
 * Main.
 */
int main( )
{

	vector<BinarySearchTree> bstree;
	vector<AvlTree> avltree;
	vector<long> bstree_ins_time;
	vector<long> avltree_ins_time;
	vector<long> bstree_search_time;
	vector<long> avltree_search_time;
	steady_clock::time_point start_time;
	steady_clock::time_point end_time;
	long elapsed_time;
	srand (time(NULL));

	for (int i=0;i<10;i++)
	{
		BinarySearchTree  btree;
		AvlTree  atree;
		vector<long> values;
		for (int v=0;v<VALUES[i];v++)
		{
		   long value= rand()%VALUES[i] +1;
		   values.push_back(value);
		}
		start_time= steady_clock::now();
		build_tree(btree,values);
		end_time= steady_clock::now();
		elapsed_time = duration_cast<milliseconds>(end_time - start_time).count();
		bstree_ins_time.push_back(elapsed_time);
		bstree.push_back(btree);
		start_time= steady_clock::now();
		build_tree(atree,values);
		end_time= steady_clock::now();
		elapsed_time = duration_cast<milliseconds>(end_time - start_time).count();
		avltree.push_back(atree);
		avltree_ins_time.push_back(elapsed_time);
	}

	cout<<"N Values ranging from 5000 to 50000 in increments of 5000"<<endl<<endl;
	cout<<"======================"<<endl;
	cout<<"Insertion Probe Counts"<<endl;
	cout<<"======================"<<endl;
	cout<<"Binary Search Tree :" << setw(10);
	for(int c=0;c<10;c++)
	{
		cout<<bstree[c].get_probe_count();
		if(c<9)
			cout<<",";
		else
			cout<<endl;
	}
	cout<<"AVL Tree :" << setw(20);
	for(int c=0;c<10;c++)
	{
		cout<<avltree[c].get_probe_count() + avltree[c].get_avl_probe_count();
		if(c<9)
			cout<<",";
		else
			cout<<endl;
	}
	cout<<endl;
	cout<<"======================"<<endl;
	cout<<"Insertion Comparison Counts"<<endl;
	cout<<"======================"<<endl;
	cout<<"Binary Search Tree :" << setw(10);
	for(int c=0;c<10;c++)
	{
		cout<<bstree[c].get_comparison_count();
		if(c<9)
			cout<<",";
		else
			cout<<endl;
	}
	cout<<"AVL Tree :" << setw(20);
	for(int c=0;c<10;c++)
	{
		cout<<avltree[c].get_comparison_count() + avltree[c].get_avl_comparison_count();
		if(c<9)
			cout<<",";
		else
			cout<<endl;
	}

	cout<<endl;
	cout<<"======================"<<endl;
	cout<<"Insertion Elapsed time"<<endl;
	cout<<"======================"<<endl;
	cout<<"Binary Search Tree :" << setw(10);
	for(int c=0;c<10;c++)
	{
		cout<<bstree_ins_time[c];
		if(c<9)
			cout<<",";
		else
			cout<<endl;
	}
	cout<<"AVL Tree :" << setw(20);
	for(int c=0;c<10;c++)
	{
		cout<<avltree_ins_time[c];
		if(c<9)
			cout<<",";
		else
			cout<<endl;
	}

	srand (time(NULL));
	for (int j=0;j<10;j++)
	{
		vector<long> search;
		for (int v=0;v<VALUES[j];v++)
		{
			long search_value= rand()%VALUES[j] +1;
			search.push_back(search_value);
		}
		start_time= steady_clock::now();
		search_tree(bstree[j],search);
		end_time= steady_clock::now();
		elapsed_time = duration_cast<milliseconds>(end_time - start_time).count();
		bstree_search_time.push_back(elapsed_time);
		start_time= steady_clock::now();
		search_tree(avltree[j],search);
		end_time= steady_clock::now();
		elapsed_time = duration_cast<milliseconds>(end_time - start_time).count();
		avltree_search_time.push_back(elapsed_time);
	}

	cout<<"======================"<<endl;
		cout<<"Search Probe Counts"<<endl;
		cout<<"======================"<<endl;
		cout<<"Binary Search Tree :" << setw(10);
		for(int c=0;c<10;c++)
		{
			cout<<bstree[c].get_search_probe_count();
			if(c<9)
				cout<<",";
			else
				cout<<endl;
		}
		cout<<"AVL Tree :" << setw(20);
		for(int c=0;c<10;c++)
		{
			cout<<avltree[c].get_search_probe_count();
			if(c<9)
				cout<<",";
			else
				cout<<endl;
		}
		cout<<endl;
		cout<<"======================"<<endl;
		cout<<"Search Comparison Counts"<<endl;
		cout<<"======================"<<endl;
		cout<<"Binary Search Tree :" << setw(10);
		for(int c=0;c<10;c++)
		{
			cout<<bstree[c].get_search_comparison_count();
			if(c<9)
				cout<<",";
			else
				cout<<endl;
		}
		cout<<"AVL Tree :" << setw(20);
		for(int c=0;c<10;c++)
		{
			cout<<avltree[c].get_search_comparison_count() ;
			if(c<9)
				cout<<",";
			else
				cout<<endl;
		}

		cout<<endl;
		cout<<"======================"<<endl;
		cout<<"Search Elapsed time"<<endl;
		cout<<"======================"<<endl;
		cout<<"Binary Search Tree :" << setw(10);
		for(int c=0;c<10;c++)
		{
			cout<<bstree_search_time[c];
			if(c<9)
				cout<<",";
			else
				cout<<endl;
		}
		cout<<"AVL Tree :" << setw(20);
		for(int c=0;c<10;c++)
		{
			cout<<avltree_search_time[c];
			if(c<9)
				cout<<",";
			else
				cout<<endl;
		}

}

void build_tree(BinarySearchTree& tree,vector<long> n)
{
	for(int k=0;k<n.size();k++)
	{
		tree.insert(n[k]);
	}

}

void search_tree(BinarySearchTree& tree,vector<long> n)
{
	for(int k=0;k<n.size();k++)
	{
		tree.contains(n[k]);
	}

}



