/*
 * BinarySearchTree.cpp
 *
 *  Created on: Nov 24, 2017
 *      Author: vineevineela
 */

#include <iostream>
#include <string>
#include "BinarySearchTree.h"

using namespace std;

BinarySearchTree::BinarySearchTree() : root(nullptr),probe_count(0),comparison_count(0),search_probe_count(0),search_comparison_count(0)
{
}

BinarySearchTree::~BinarySearchTree()
{
    clear();
}

BinaryNode *BinarySearchTree::getRoot() const { return root; }

int BinarySearchTree::height()  { return height(root); }
long BinarySearchTree::get_probe_count() const {return probe_count;}
long BinarySearchTree::get_comparison_count() const {return comparison_count;}

long BinarySearchTree::get_search_probe_count() const {return search_probe_count;}
long BinarySearchTree::get_search_comparison_count() const {return search_comparison_count;}

void BinarySearchTree::increment_probe_count(){probe_count++;}
void BinarySearchTree::increment_comparison_count(){comparison_count++;}

int BinarySearchTree::height(const BinaryNode *ptr)
{
	increment_probe_count();
    if (ptr == nullptr)
        return -1;
    else
    {

    		int lheight=height(ptr->left);
    		int rheight=height(ptr->right);
    		if(lheight>rheight)
    			return (lheight+1);
    		else
    			return (rheight+1);
    }

}

long BinarySearchTree::findMin()  throw(string)
{
    if (isEmpty()) throw(string("Empty tree"));
    increment_probe_count();
    return findMin(root)->data;
}

BinaryNode *BinarySearchTree::findMin(BinaryNode *ptr)
{
	if (ptr == nullptr)       return nullptr;
	if (ptr->left == nullptr)
	{
		increment_probe_count();
		return ptr;
	}
	while(ptr->left != nullptr)
	{
		increment_probe_count();
		ptr=ptr->left;
	}
	return ptr;
}

long BinarySearchTree::findMax()  throw(string)
{
    if (isEmpty()) throw(string("Empty tree"));
    increment_probe_count();
    return findMax(root)->data;
}

BinaryNode *BinarySearchTree::findMax(BinaryNode *ptr)
{
    if (ptr != nullptr)
    {
    		increment_probe_count();
        while(ptr->right != nullptr) ptr = ptr->right;
    }

    return ptr;

}

void BinarySearchTree::clear()
{
    clear(root);
}
//did not use this function
void BinarySearchTree::clear(BinaryNode* &ptr)
{
    /***** Complete this function. *****/
}

bool BinarySearchTree::isEmpty() const
{
    return root == nullptr;
}

bool BinarySearchTree::contains(const long data)
{
	search_probe_count++;
    return contains(data, root);
}

bool BinarySearchTree::contains(const long data, BinaryNode *ptr)
{
    while (ptr != nullptr)
    {
    		search_probe_count++;

        if (data < ptr->data)
        {
        	    search_comparison_count++;
            ptr = ptr->left;
        }
        else if (data > ptr->data)
        {
        		search_comparison_count++;
            ptr = ptr->right;
        }
        else
        {
            return true;  // found
        }
    }

    return false;
}

void BinarySearchTree::insert(const long data)
{
    insert(data, root);
}

void BinarySearchTree::insert(const long data, BinaryNode* &ptr)
{
//    cout << "=== Insert called on "
//         << (ptr != nullptr ? to_string(ptr->data) : "null")
//         << endl;

    /***** Complete this function. *****/
	probe_count++;
	 if (ptr == nullptr)
	    {
	        ptr = new BinaryNode (data);
	    }
	    else if (data < ptr->data)
	    {
	    		comparison_count++;
	        insert(data, ptr->left);
	    }
	    else if (data > ptr->data)
	    {
	    		comparison_count++;
	        insert(data, ptr->right);
	    }

}

void BinarySearchTree::remove(const long data)
{
    remove(data, root);
}

void BinarySearchTree::remove(const long data, BinaryNode* &ptr)
{
//    cout << "=== Remove called on "
//         << (ptr != nullptr ? to_string(ptr->data) : "null")
//         << endl;

	if (ptr == nullptr) return;

	    if (data < ptr->data)
	    {
	        remove(data, ptr->left);
	    }
	    else if (data > ptr->data)
	    {
	        remove(data, ptr->right);
	    }
	    else if (   (ptr->left  != nullptr)
	             && (ptr->right != nullptr))
	    {
	        ptr->data = findMin(ptr->right)->data;
	        remove(ptr->data, ptr->right);
	    }
	    else
	    {
	        BinaryNode *oldNode = ptr;
	        ptr = (ptr->left != nullptr) ? ptr->left: ptr->right;
	        delete oldNode;
	    }
}



