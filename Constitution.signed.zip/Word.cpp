#include <string>
#include "Word.h"
using namespace std;

/***** Modify this file as needed. *****/

Word::Word() : text(""), count(0) {}
Word::Word(string text) : text(text), count(1) {}
string Word::get_text() { return text;}
void Word::increment_count(){ count++;}
int Word::get_count() { return count;}
bool operator != (Word w1,Word w2)
{
	if((w1.get_text()==w2.get_text()) && (w1.get_count()==w2.get_count()) )
		return 0;
	else
		return 1;
}
Word::~Word() {}
