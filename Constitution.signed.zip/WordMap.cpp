#include <iostream>
#include <map>
#include "WordMap.h"

/***** Complete this file. *****/

using namespace std;

WordMap::WordMap()
{

}

WordMap::~WordMap()
{

}

Word *WordMap::insert(const string text)
{
    /***** Complete this member function. *****/
	Word w(text);
	if(data.size()==0)
	    data.insert(std::pair<string,Word>(text,w));
	else
	    	{
		if(data.find(text)==data.end())
			data.insert(std::pair<string,Word>(text,w));
		else
		    data.find(text)->second.increment_count();
	    	}
	    return &w;
}

Word *WordMap::search(const string text)
{
    if(data.find(text)==data.end())
    		return new Word();
    else
    		return &data.find(text)->second;
}

int WordMap::get_size()
{
	return data.size();
}

map<string, Word> WordMap::get_data()
{
	return data;
}