#include <iostream>
#include <vector>
#include <string>
#include "WordVector.h"

/***** Complete this file. *****/

using namespace std;

WordVector::WordVector()
{

}

WordVector::~WordVector()
{

}

Word *WordVector::insert(const string text)
{
    Word w(text);
    if(data.size()==0)
    		data.push_back(w);
    	else
    	{
    		vector <Word>::iterator iter=data.begin();
    		while(iter->get_text()<text && iter!=data.end())
    		{
    			advance(iter,1);
    		}
    		if(iter==data.end())
    			data.push_back(w);
    		else if (iter->get_text()==text)
    		{
    			iter->increment_count();
    			w.increment_count();
    		}
    		else
    			data.insert(iter,w);
    	}
    return &w;
}

Word *WordVector::search(const string text)
{
	int start=0;
	int end=data.size()-1;
	int mid;
	while(start<=end)
	{
		mid=(start+end)/2;
		if (data.at(mid).get_text()>text)
		{
			end=mid-1;
		}
		else if (data.at(mid).get_text()<text)
		{
			start=mid+1;
		}
		else if (data.at(mid).get_text()==text)
			return &data.at(mid);
	}
		return new Word();
}

int WordVector::get_size()
{
	return data.size();
}

vector<Word> WordVector::get_data()
{
	return  data;
}