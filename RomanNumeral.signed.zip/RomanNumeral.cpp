#include <iostream>
#include "RomanNumeral.h"
using namespace std;

const int M=1000;
const int D=500;
const int C=100;
const int L=50;
const int X=10;
const int V=5;
const int I=1;

RomanNumeral::RomanNumeral() : roman(""), decimal(0)
{
}

RomanNumeral::RomanNumeral(string str) : roman(str),decimal(to_decimal(str))
{
}

RomanNumeral::RomanNumeral(int dec) : roman(to_roman(dec)),decimal(dec)
{
}
//converts the given decimal number into roman string
//@param decimal number which u want to convert to roman
string RomanNumeral::to_roman(int dec)
{
	string str="";
	int d=dec;
	int remainder=0;
	if(d/1000>=1)
	{
		remainder=d/1000;
		for(int i=0;i<remainder;i++)
			str.append("M");
		d=d%1000;
	}
	if(d/100>=1)
	{
		if(d/100>=9)
		{
			str.append("CM");
		}
		else if (d/100>=5 and d/100<9)
		{
			str.append("D");
			remainder=(d-D)/100;
			for(int i=0;i<remainder;i++)
				str.append("C");
		}
		else if(d/100==4)
		{
			str.append("CD");
		}
		else
		{
			remainder=d/100;
			for(int i=0;i<remainder;i++)
			str.append("C");
		}
		d=d%100;
	}
	if(d/10>=1)
	{
		if(d/10>=9)
		{
			str.append("XC");
		}
		else if (d/10>=5 and d/10<9)
		{
			str.append("L");
			remainder=(d-L)/10;
			for(int i=0;i<remainder;i++)
				str.append("X");
		}
		else if(d/10==4)
		{
			str.append("XL");
		}
		else
		{
			remainder=d/10;
			for(int i=0;i<remainder;i++)
				str.append("X");
		}
		d=d%10;
	}
	if(d>=1)
	{
		if(d==9)
		{
			str.append("IX");
		}
		else if (d>=5 and d<9)
		{
			str.append("V");
			remainder=d-V;
			for(int i=0;i<remainder;i++)
				str.append("I");
		}
		else if(d==4)
		{
	   		str.append("IV");
		}
		else
		{
			remainder=d;
			for(int i=0;i<remainder;i++)
				str.append("I");
		}
	}
	return str;
}
//to convert roman to decimal
//@param roman string for which you want a decimal
int RomanNumeral::to_decimal(string str)
{
	int d=0;
	const char * ch = str.c_str();
	for(int i=0;i<str.length();i++)
	{
		if(*(ch+i) =='M')
		{
			d=d+M;
		}
		else if(*(ch+i)=='D')
		{
			d=d+D;
		}
		else if (*(ch+i)=='C')
		{
			if(*(ch+i+1)=='M')
			{
				d=d+M-C;
				i=i+1;
			}
			else if(*(ch+i+1)=='D')
			{
				d=d+D-C;
				i=i+1;
			}
			else
			{
				d=d+C;
			}
		}
		else if(*(ch+i) =='L')
		{
			if(*(ch+i+1)=='D')
			{
				d=d+D-L;
				i=i+1;
			}
			else if(*(ch+i+1)=='C')
			{
				d=d+C-L;
				i=i+1;
			}
			else
			{
				d=d+L;
			}
		}
		else if(*(ch+i)=='X')
		{
			if(*(ch+i+1)=='C')
			{
				d=d+C-X;
				i=i+1;
			}
			else if(*(ch+i+1)=='L')
			{
				d=d+L-X;
				i=i+1;
			}
			else
			{
				d=d+X;
			}
		}
		else if(*(ch+i)=='V')
		{
			if(*(ch+i+1)=='L')
			{
				d=d+L-V;
				i=i+1;
			}
			else if(*(ch+i+1)=='X')
			{
				d=d+X-V;
				i=i+1;
			}
			else
			{
				d=d+V;
			}
		}
		else
		{
			if(*(ch+i+1)=='X')
			{
				d=d+X-I;
				i=i+1;
			}
			else if(*(ch+i+1)=='V')
			{
				d=d+V-I;
				i=i+1;
			}
			else
			{
				d=d+I;
			}
		}
	}
	return d;
}

string RomanNumeral::get_romanstr(const RomanNumeral & rn) const
{
	return roman;
}

int RomanNumeral::get_romanint(const RomanNumeral & rn) const
{
	return decimal;
}

RomanNumeral RomanNumeral::operator + (const RomanNumeral &rn)
{
	RomanNumeral rnadd;
	rnadd.decimal=decimal+rn.decimal;
	rnadd.roman=to_roman(rnadd.decimal);
	return rnadd;
}

RomanNumeral RomanNumeral::operator - (const RomanNumeral &rn)
{
	RomanNumeral rnsub;
	rnsub.decimal=decimal - rn.decimal;
	rnsub.roman=to_roman(rnsub.decimal);
	return rnsub;
}

RomanNumeral RomanNumeral::operator * (const RomanNumeral &rn)
{
	RomanNumeral rnmul;
	rnmul.decimal=decimal*rn.decimal;
	rnmul.roman=to_roman(rnmul.decimal);
	return rnmul;
}

RomanNumeral RomanNumeral::operator / (const RomanNumeral &rn)
{
	RomanNumeral rndiv;
	rndiv.decimal=decimal / rn.decimal;
	rndiv.roman=to_roman(rndiv.decimal);
	return rndiv;
}

bool RomanNumeral::operator == (const RomanNumeral &rn) const
{
	return decimal==rn.decimal;
}

bool RomanNumeral::operator != (const RomanNumeral &rn) const
{
	return decimal!=rn.decimal;
}

istream& operator >> (istream& in_stream,RomanNumeral &rn)
{
	in_stream>>rn.roman;
	string str=rn.roman;
	rn.decimal=rn.to_decimal(str);
	return in_stream;
}
ostream& operator << (ostream& out_stream,const RomanNumeral &rn)
{
	out_stream<<"["<<rn.decimal<<":"<<rn.roman<<"]";
	return out_stream;
}

