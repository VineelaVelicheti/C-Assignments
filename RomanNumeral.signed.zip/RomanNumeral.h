#ifndef ROMANNUMERAL_H_
#define ROMANNUMERAL_H_
#include<stdio.h>
#include<string>

using namespace std;

class RomanNumeral
{

    friend istream& operator >> (istream& in_stream,RomanNumeral &rn) ;
    friend ostream& operator << (ostream& out_stream,const RomanNumeral &rn) ;
    public:
    /**
     * Default constructor.
     */
    RomanNumeral();
    RomanNumeral(string str);
    RomanNumeral(int dec);

    string get_romanstr(const RomanNumeral & rn) const;
    int get_romanint(const RomanNumeral & rn) const;

    RomanNumeral operator + (const RomanNumeral &rn) ;
    RomanNumeral operator - (const RomanNumeral &rn) ;
    RomanNumeral operator * (const RomanNumeral &rn) ;
    RomanNumeral operator / (const RomanNumeral &rn) ;
    bool operator == (const RomanNumeral &rn) const;
    bool operator != (const RomanNumeral &rn) const;

private:
    string roman;
    int decimal;

    string to_roman(int dec) ;
    int to_decimal(string str);

};

#endif /* ROMANNUMERAL_H_ */